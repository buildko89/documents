#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import time
import numpy as np
import pprint
import hakoniwa_pdu.apps.drone.hakosim as hakosim

def parse_lidarData(data):
    """LiDARのpoint_cloudを [x,y,z] 配列に変換"""
    points = np.array(data.point_cloud, dtype=np.dtype('f4'))
    points = np.reshape(points, (int(points.shape[0]/3), 3))
    return points

def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_path>")
        return 1

    # --- 接続と準備 ---
    client = hakosim.MultirotorClient(sys.argv[1], "Drone")
    client.confirmConnection()
    client.enableApiControl(True)
    client.armDisarm(True)

    # --- 離陸 ---
    print("離陸します...")
    client.takeoff(1.0)
    time.sleep(2)

    # --- ホバリング中に 2-1, 2-2, 2-3 を実行 ---

    # 2-1: カメラ撮影（前方）
    print("[2-1] カメラ撮影（前方）")
    client.simSetCameraOrientation("0", 0)
    png_image = client.simGetImage("0", hakosim.ImageType.Scene)
    if png_image:
        with open("stage2_1_scene.png", "wb") as f:
            f.write(png_image)
        print("画像を保存しました: stage2_1_scene.png")
    time.sleep(1)

    # 2-2: カメラ向き変更（下向き撮影）
    print("[2-2] カメラ向き変更（下向き）")
    client.simSetCameraOrientation("0", -90)
    png_image_down = client.simGetImage("0", hakosim.ImageType.Scene)
    if png_image_down:
        with open("stage2_2_scene_down.png", "wb") as f:
            f.write(png_image_down)
        print("画像を保存しました: stage2_2_scene_down.png")
    time.sleep(1)

    # 2-3: LiDARデータ取得
    print("[2-3] LiDARデータ取得")
    lidarData = client.getLidarData()
    if len(lidarData.point_cloud) < 3:
        print("LiDARデータなし")
    else:
        points = parse_lidarData(lidarData)
        print(f"LiDAR点群数: {len(points)}")
        print(f"LiDAR位置: {pprint.pformat(lidarData.pose.position)}")
        # 2m以内の障害物を抽出
        close_points = points[np.linalg.norm(points, axis=1) <= 2.0]
        print(f"2m以内の障害物数: {len(close_points)}")

    # --- 着陸 ---
    print("着陸します...")
    client.land()
    return 0

if __name__ == "__main__":
    sys.exit(main())
