#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, time
import hakoniwa_pdu.apps.drone.hakosim as hakosim

def transport(client, baggage_pos, transfer_pos):
    client.moveToPosition(baggage_pos['x'], baggage_pos['y'], 1, 1)
    client.grab_baggage(True)
    time.sleep(1)
    client.moveToPosition(transfer_pos['x'], transfer_pos['y'], 1, 1)
    client.grab_baggage(False)

def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_path>")
        return 1

    client = hakosim.MultirotorClient(sys.argv[1], "Drone")
    client.confirmConnection()
    client.enableApiControl(True)
    client.armDisarm(True)
    client.takeoff(1.0)

    baggage_pos = {'x': 1.0, 'y': 0.0}
    transfer_pos = {'x': 0.0, 'y': 1.0}
    transport(client, baggage_pos, transfer_pos)

    client.land()
    return 0

if __name__ == "__main__":
    sys.exit(main())
