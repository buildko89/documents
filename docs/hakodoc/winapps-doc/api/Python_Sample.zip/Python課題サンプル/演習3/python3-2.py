#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, numpy as np
import hakoniwa_pdu.apps.drone.hakosim as hakosim

def parse_lidarData(data):
    points = np.array(data.point_cloud, dtype=np.dtype('f4'))
    points = np.reshape(points, (int(points.shape[0]/3), 3))
    return points

def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_path>")
        return 1

    client = hakosim.MultirotorClient(sys.argv[1], "Drone")
    client.confirmConnection()
    client.enableApiControl(True)
    client.armDisarm(True)
    client.takeoff(1.0)

    lidarData = client.getLidarData()
    points = parse_lidarData(lidarData)

    forward_condition = (points[:,0] > 0) & (np.linalg.norm(points, axis=1) < 1.5)
    if np.any(forward_condition):
        print("障害物検出！左に回避")
        client.moveToPosition(0, 1, 1, 1)
    else:
        print("障害物なし。直進")
        client.moveToPosition(2, 0, 1, 1)

    client.land()
    return 0

if __name__ == "__main__":
    sys.exit(main())
