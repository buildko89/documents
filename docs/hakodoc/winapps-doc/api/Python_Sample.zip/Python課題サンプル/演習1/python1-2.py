#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, time, math
import hakoniwa_pdu.apps.drone.hakosim as hakosim

def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_path>")
        return 1

    client = hakosim.MultirotorClient(sys.argv[1], "Drone")
    client.confirmConnection()
    client.enableApiControl(True)
    client.armDisarm(True)
    client.takeoff(1.0)

    for _ in range(5):
        pose = client.simGetVehiclePose()
        roll, pitch, yaw = hakosim.hakosim_types.Quaternionr.quaternion_to_euler(pose.orientation)
        print(f"POS: {pose.position.x_val:.2f}, {pose.position.y_val:.2f}, {pose.position.z_val:.2f}")
        print(f"ANGLE(deg): {math.degrees(roll):.1f}, {math.degrees(pitch):.1f}, {math.degrees(yaw):.1f}")
        time.sleep(1)

    client.land()
    return 0

if __name__ == "__main__":
    sys.exit(main())
