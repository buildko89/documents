#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, time
import hakoniwa_pdu.apps.drone.hakosim as hakosim

def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_path>")
        return 1

    client = hakosim.MultirotorClient(sys.argv[1], "Drone")
    client.confirmConnection()
    client.enableApiControl(True)
    client.armDisarm(True)

    # 離陸（高度1m）
    client.takeoff(1.0)
    time.sleep(3)

    # 着陸
    client.land()
    return 0

if __name__ == "__main__":
    sys.exit(main())
