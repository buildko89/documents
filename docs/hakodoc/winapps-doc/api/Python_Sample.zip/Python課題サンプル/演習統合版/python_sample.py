#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import time
import math
import numpy as np
import pprint
import hakoniwa_pdu.apps.drone.hakosim as hakosim

# --- 共通ユーティリティ ---
def debug_pos(client):
    pose = client.simGetVehiclePose()
    print(f"POS  : {pose.position.x_val:.2f} {pose.position.y_val:.2f} {pose.position.z_val:.2f}")
    roll, pitch, yaw = hakosim.hakosim_types.Quaternionr.quaternion_to_euler(pose.orientation)
    print(f"ANGLE: {math.degrees(roll):.1f} {math.degrees(pitch):.1f} {math.degrees(yaw):.1f}")

def parse_lidarData(data):
    points = np.array(data.point_cloud, dtype=np.dtype('f4'))
    points = np.reshape(points, (int(points.shape[0]/3), 3))
    return points

# --- Stage1: 基礎操作（Arts: 図形飛行, Math: 距離計算） ---
def stage1_basic_flight(client):
    print("\n=== Stage1: 基礎操作 ===")
    client.takeoff(1.0)
    debug_pos(client)

    # 三角形経路飛行（Arts要素）
    waypoints = [(1, 0, 1), (0.5, 0.866, 1), (0, 0, 1)]
    total_distance = 0.0
    prev = (0, 0, 1)

    for wp in waypoints:
        client.moveToPosition(wp[0], wp[1], wp[2], 1)
        dist = math.dist(prev, wp)
        total_distance += dist
        prev = wp
        time.sleep(2)
        debug_pos(client)

    print(f"総飛行距離（推定）: {total_distance:.2f} m")
    time.sleep(2)

# --- Stage2: センサー活用（Science: LiDAR原理, Tech: OpenCV等で注釈可） ---
def stage2_sensor_usage(client):
    print("\n=== Stage2: センサー活用 ===")
    lidarData = client.getLidarData()
    if len(lidarData.point_cloud) < 3:
        print("No points from LiDAR")
        return

    points = parse_lidarData(lidarData)
    print(f"LiDAR points: {len(points)}")
    print(f"LiDAR position: {pprint.pformat(lidarData.pose.position)}")

    # 2m以内の障害物を抽出（Science要素）
    condition = np.linalg.norm(points, axis=1) <= 2.0
    close_points = points[condition]
    print(f"2m以内の障害物数: {len(close_points)}")

    # カメラ撮影（Tech要素）
    client.simSetCameraOrientation("0", 0)
    png_image = client.simGetImage("0", hakosim.ImageType.Scene)
    if png_image:
        with open("stage2_scene.png", "wb") as f:
            f.write(png_image)
        print("カメラ画像を保存しました: stage2_scene.png")

# --- Stage3: 応用ミッション（Engineering: 障害物回避, Arts: 飛行ログ可視化） ---
def stage3_mission(client):
    print("\n=== Stage3: 応用ミッション ===")
    # 簡易障害物回避ミッション
    target = (2, 0, 1)
    lidarData = client.getLidarData()
    points = parse_lidarData(lidarData)

    # 前方1.5m以内に障害物があるかチェック
    forward_condition = (points[:,0] > 0) & (np.linalg.norm(points, axis=1) < 1.5)
    if np.any(forward_condition):
        print("障害物検出！回避経路を取ります")
        client.moveToPosition(0, 1, 1, 1)  # 左に回避
    else:
        print("障害物なし。直進します")
        client.moveToPosition(*target, 1)

    time.sleep(2)
    debug_pos(client)

# --- メイン ---
def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <config_path>")
        return 1

    client = hakosim.MultirotorClient(sys.argv[1], "Drone")
    client.confirmConnection()
    client.enableApiControl(True)
    client.armDisarm(True)

    # Stage1〜Stage3 実行
    stage1_basic_flight(client)
    stage2_sensor_usage(client)
    stage3_mission(client)

    # 着陸
    client.land()
    debug_pos(client)
    return 0

if __name__ == "__main__":
    sys.exit(main())
