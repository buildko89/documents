#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
PX4ドローンをゲームコントローラで操作（修正版）
再アーム（着陸後の再離陸）の問題を解決
"""

import pygame
import time
import math
import argparse
import sys
import os
from pymavlink import mavutil
from typing import Optional

# rc_utils を修正後のディレクトリから読み込む
sys.path.insert(0, os.path.dirname(__file__))
from rc.rc_utils.rc_utils import RcConfig, StickMonitor

from hakosim_controllers_px4 import PX4Controller


class PX4RcController:
    """
    PX4をゲームコントローラで操作
    rc-custom.pyと同じスタイルでイベント処理
    """
    
    BUTTON_ARM_TOGGLE = 0       # RadioControlEnable -> アーム切替
    BUTTON_TAKEOFF = 3          # ReturnHome -> 離陸
    BUTTON_LAND = 1             # GrabBaggage -> 着陸
    BUTTON_HOVER_TOGGLE = 2     # Camera -> ホバー切替
    
    def __init__(self,
                 connection_str: str,
                 rc_config_path: str,
                 max_vel: float = 3.0,
                 max_yaw_deg_s: float = 45.0,
                 rate_hz: float = 10.0):
        
        self.connection_str = connection_str
        self.max_vel = max_vel
        self.max_yaw_deg_s = max_yaw_deg_s
        self.rate_hz = rate_hz
        self.dt = 1.0 / rate_hz
        
        # RC設定の読み込み
        self.rc_config = RcConfig(rc_config_path)
        if self.rc_config.config is None:
            raise RuntimeError(f"Failed to load RC config: {rc_config_path}")
        
        self.stick_monitor = StickMonitor(self.rc_config)
        
        print(f"Controller Config: {rc_config_path}")
        print(f"Mode: {self.rc_config.config['mode']}")
        
        # MAVLink接続
        self.mav_conn: Optional[mavutil.mavlink_connection] = None
        self.controller: Optional[PX4Controller] = None
        
        # Pygame初期化
        pygame.init()
        pygame.joystick.init()
        
        if pygame.joystick.get_count() == 0:
            raise RuntimeError("ゲームコントローラが接続されていません")
        
        self.joystick = pygame.joystick.Joystick(0)
        self.joystick.init()
        
        print(f"ジョイスティックの名前: {self.joystick.get_name()}")
        
        # --- 状態管理フラグ ---
        self.armed = False
        self.offboard = False
        
        # 【修正】セットポイント送信許可フラグを追加
        # OFFBOARDモードに入る前からデータを送るために必要
        self.send_setpoints = False 
        
        self.hover_mode = False
        self.takeoff_mode = False
        self.velocity_scale = 1.0
        
        # NED座標での速度指令
        self.vx_ned = 0.0
        self.vy_ned = 0.0
        self.vz_ned = 0.0
        self.yaw_deg = 0.0
        
        # スティックの現在値
        self.axis_values = [0.0] * 4  # TURN_LR, UP_DOWN, MOVE_LR, MOVE_FB
    
    def connect(self) -> bool:
        """MAVLinkに接続"""
        try:
            print(f"[接続] {self.connection_str}")
            self.mav_conn = mavutil.mavlink_connection(
                self.connection_str,
                source_system=255,
                source_component=190
            )
            
            print("[待機] ハートビート...")
            self.mav_conn.wait_heartbeat()
            print(f"✓ システム {self.mav_conn.target_system}")
            
            # PX4Controllerを初期化
            self.controller = PX4Controller()
            self.controller.init_connection(self.mav_conn)
            
            return True
            
        except Exception as e:
            print(f"✗ 接続エラー: {e}")
            return False
    
    def disconnect(self):
        """切断"""
        if self.controller:
            self.controller.stop_movement()
        if self.mav_conn:
            self.mav_conn.close()
        pygame.joystick.quit()
        pygame.quit()
        print("✓ 切断完了")
    
    def arm(self) -> bool:
        """アーム"""
        print("[ARM] 実行中...")
        # 【修正】以前のコードにあった STABILIZED への強制変更は、
        # OFFBOARD復帰ロジックの邪魔になることがあるため、
        # ここでは純粋にArmコマンドのみを送ります。
        
        if self.controller.arm():
            self.armed = True
            print("✓ ARM 成功")
            return True
        print("✗ ARM 失敗")
        return False
    
    def disarm(self) -> bool:
        """ディスアーム"""
        print("[DISARM] 実行中...")
        
        # 送信停止
        self.send_setpoints = False
        self.offboard = False
        self.controller.stop_movement()
        time.sleep(0.2)

        if self.controller.disarm():
            self.armed = False
            print("✓ DISARM 成功")
            return True
        print("✗ DISARM 失敗")
        return False

    def set_offboard(self) -> bool:
        """OFFBOARDモードに設定"""
        # 【修正】「アームされていないとOFFBOARDにしない」という制限を削除
        # PX4はセットポイントさえ来ていれば、Disarm状態でもOFFBOARDに入れます。
        # これにより「OFFBOARDに入れる -> Armする」という順序が可能になります。
        
        print("[OFFBOARD] 設定中...")
        
        # ストリームが動いているか確認（念のため）
        if not self.send_setpoints:
            print("⚠ 警告: データ送信が許可されていません。強制的に開始します。")
            self.vx_ned, self.vy_ned, self.vz_ned = 0, 0, 0
            self.send_setpoints = True
            self._update_velocity_command()

        if self.controller.set_api_mode():
            self.offboard = True
            print("✓ OFFBOARD 成功")
            return True
        print("✗ OFFBOARD 失敗")
        return False
    
    def land(self) -> bool:
        """着陸"""
        if not self.armed:
            return True

        print("[LAND] 実行中...")
        
        # 1. セットポイント送信を完全に止める
        self.send_setpoints = False
        self.offboard = False
        self.takeoff_mode = False
        
        # 2. コントローラー側のストリームスレッドを確実に止める
        if self.controller:
            self.controller.stop_movement()
        
        # 3. PX4にLANDコマンドを送信
        # 既にLANDモードなら送らない、といったガードを入れるとより安定します
        success = self.controller.land()
        
        if success:
            print("✓ LAND コマンド受理 (自動着陸開始)")
            # ここで self.armed = False にはせず、
            # PX4からの状態フィードバック(Heartbeat)でDisarmを検知するのが理想ですが、
            # 簡易的にはここでフラグを落としても良いでしょう。
            self.armed = False 
        else:
            print("✗ LAND 失敗（すでに着陸中か、モード遷移不可）")
            
        return success
    
    def joystick_control(self):
        """メイン制御ループ"""
        print("\n=== 操作ガイド ===")
        print("左スティック（Mode2）: 前後・ヨー回転")
        print("右スティック（Mode2）: 左右・上下")
        print(f"ボタン{self.BUTTON_ARM_TOGGLE}: アーム/ディスアーム切替")
        print(f"ボタン{self.BUTTON_TAKEOFF}: 離陸モード")
        print(f"ボタン{self.BUTTON_LAND}: 着陸")
        print(f"ボタン{self.BUTTON_HOVER_TOGGLE}: ホバー切替")
        print("Ctrl+C: 終了\n")
        
        try:
            last_update = time.time()
            
            while True:
                # rc-custom.pyスタイルのイベント処理
                for event in pygame.event.get():
                    if event.type == pygame.JOYAXISMOTION:
                        if event.axis < 6:
                            op_index = self.stick_monitor.rc_config.get_op_index(event.axis)
                            stick_value = self.stick_monitor.stick_value(event.axis, event.value)
                            if stick_value is not None and op_index < len(self.axis_values):
                                self.axis_values[op_index] = stick_value
                                
                    elif event.type == pygame.JOYBUTTONDOWN or event.type == pygame.JOYBUTTONUP:
                        if event.button < 16:
                            event_op_index = self.stick_monitor.rc_config.get_event_op_index(event.button)
                            if event_op_index is not None:
                                event_triggered = self.stick_monitor.switch_event(
                                    event.button, (event.type == pygame.JOYBUTTONDOWN)
                                )
                                self._handle_button_event(event_op_index, event_triggered)
                
                # 定期的に速度指令を送信（10Hz）
                current_time = time.time()
                if current_time - last_update >= self.dt:
                    self._update_velocity_command()
                    last_update = current_time
                
                time.sleep(0.01)
                
        except KeyboardInterrupt:
            print("\n中断されました")
        finally:
            self.cleanup()
    
    def _handle_button_event(self, event_op_index: int, triggered: bool):
        """ボタンイベントの処理"""
        
        # RadioControlEnable -> アーム/ディスアーム切替
        if event_op_index == self.rc_config.SWITCH_RADIO_CONTROL_ENABLE:
            if triggered:
                if not self.armed:
                    # 【重要】再アーム手順の修正
                    print("--- 起動シーケンス開始 ---")
                    
                    # 1. まず速度ゼロでデータ送信を開始する
                    # これがないとPX4はモード遷移を拒否する
                    self.vx_ned = 0.0
                    self.vy_ned = 0.0
                    self.vz_ned = 0.0
                    self.send_setpoints = True
                    self._update_velocity_command() # 即座に1回送信
                    
                    print(" >> データストリーム開始待機...")
                    time.sleep(0.5) 
                    
                    # 2. OFFBOARDモードへ切り替え (Disarm状態でもOK)
                    if self.set_offboard():
                        # 3. モード切替成功後にアームする
                        time.sleep(0.2)
                        if self.arm():
                            print("Done.")
                        else:
                            print("アーム失敗のため停止")
                            self.send_setpoints = False
                            self.offboard = False
                    else:
                        print("OFFBOARD切替失敗のため停止")
                        self.send_setpoints = False
                        
                else:
                    self.disarm()
        
        # GrabBaggage -> 着陸
        elif event_op_index == self.rc_config.SWITCH_GRAB_BAGGAGE:
            if triggered:
                self.land()
        
        # Camera -> ホバー切替
        elif event_op_index == self.rc_config.SWITCH_CAMERA_SHOT:
            if triggered:
                self.hover_mode = not self.hover_mode
                print(f"[ホバー] {'ON' if self.hover_mode else 'OFF'}")
        
        # ReturnHome -> 離陸モード
        elif event_op_index == self.rc_config.SWITCH_RETURN_HOME:
            if triggered:
                if self.armed and self.offboard:
                    self.takeoff_mode = not self.takeoff_mode
                    if self.takeoff_mode:
                        print("[離陸モード] ON: 上昇します")
                    else:
                        print("[離陸モード] OFF")
    
    def _update_velocity_command(self):
        """速度指令の更新と送信"""
        
        # 【修正】 offboardフラグだけでなく、send_setpointsフラグを見る
        if not self.send_setpoints or not self.controller:
            return
        
        # まだOFFBOARDになっていない準備期間中は、スティック入力を無視してゼロを送る
        if not self.offboard:
            self.vx_ned = 0.0
            self.vy_ned = 0.0
            self.vz_ned = 0.0
            # yaw_deg はそのまま維持
            
        else:
            # --- 以下は通常の操作ロジック ---
            turn_lr = self.axis_values[self.rc_config.STICK_TURN_LR]
            up_down = self.axis_values[self.rc_config.STICK_UP_DOWN]
            move_lr = self.axis_values[self.rc_config.STICK_MOVE_LR]
            move_fb = self.axis_values[self.rc_config.STICK_MOVE_FB]
            
            if not self.hover_mode and not self.takeoff_mode:
                v_forward = move_fb * self.max_vel * self.velocity_scale
                v_right = move_lr * self.max_vel * self.velocity_scale
                
                # 【対症療法】ヨーが南向き(90-270度)の時にロールが反転する問題への回避策
                v_right_eff = v_right
                if 90.0 < self.yaw_deg < 270.0:
                    v_right_eff = -v_right
                
                # 目標のヨー角を使って速度変換する
                target_yaw_rad = math.radians(self.yaw_deg)
                
                # 正しい回転行列の式を使用
                self.vx_ned = v_forward * math.cos(target_yaw_rad) - v_right_eff * math.sin(target_yaw_rad)
                self.vy_ned = v_forward * math.sin(target_yaw_rad) + v_right_eff * math.cos(target_yaw_rad)
                self.vz_ned = -up_down * self.max_vel * self.velocity_scale
                
                # ヨー角の正規化を 0-360° に戻す
                # 修正: スティック操作と回転方向を合わせるため符号を反転
                yaw_change = -turn_lr * self.max_yaw_deg_s * self.velocity_scale * self.dt
                self.yaw_deg = (self.yaw_deg + yaw_change) % 360.0
            
            elif self.hover_mode:
                self.vx_ned = 0.0
                self.vy_ned = 0.0
                self.vz_ned = 0.0
            
            if self.takeoff_mode:
                self.vz_ned = -0.5
        
        # 速度指令を送信 (hakosim側でスレッドが停止していても再開される)
        self.controller.set_velocity_ned(
            self.vx_ned,
            self.vy_ned,
            self.vz_ned,
            self.yaw_deg
        )
        
        # デバッグ出力 (OFFBOARD中のみ)
        if self.offboard and (abs(self.vx_ned) > 0.1 or abs(self.vz_ned) > 0.1):
            # ログが出すぎないように少し頻度落としても良いがそのまま
            print(f"[速度] vx:{self.vx_ned:+.2f} vy:{self.vy_ned:+.2f} "
                  f"vz:{self.vz_ned:+.2f} yaw:{self.yaw_deg:.1f}°")
    
    def cleanup(self):
        """クリーンアップ"""
        print("\n[クリーンアップ]")
        if self.controller:
            self.controller.stop_movement()
        time.sleep(0.5)
        if self.armed:
            self.disarm()


def main():
    parser = argparse.ArgumentParser(
        description="PX4ドローンをゲームコントローラで操作"
    )
    parser.add_argument(
        "rc_config_path",
        help="RC設定ファイルのパス"
    )
    parser.add_argument(
        "--connection",
        default="udp:127.0.0.1:14540",
        help="MAVLink接続文字列"
    )
    parser.add_argument("--max-vel", type=float, default=3.0)
    parser.add_argument("--max-yaw", type=float, default=45.0)
    parser.add_argument("--rate", type=float, default=10.0)
    
    args = parser.parse_args()
    
    if not os.path.exists(args.rc_config_path):
        print(f"ERROR: RC config file not found: '{args.rc_config_path}'")
        return 1
    
    try:
        ctrl = PX4RcController(
            connection_str=args.connection,
            rc_config_path=args.rc_config_path,
            max_vel=args.max_vel,
            max_yaw_deg_s=args.max_yaw,
            rate_hz=args.rate
        )
        
        if not ctrl.connect():
            return 1
        
        ctrl.joystick_control()
        
    except Exception as e:
        print(f"エラー: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    finally:
        if 'ctrl' in locals():
            ctrl.disconnect()
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
