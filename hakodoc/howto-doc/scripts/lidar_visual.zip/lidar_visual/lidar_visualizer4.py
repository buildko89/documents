#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import os
import time
import argparse
import numpy as np
import struct
import signal
import json

try:
    import hakopy
    from hakoniwa_pdu.pdu_manager import PduManager
    from hakoniwa_pdu.impl.shm_communication_service import ShmCommunicationService
    from hakoniwa_pdu.pdu_msgs.sensor_msgs.pdu_conv_PointCloud2 import pdu_to_py_PointCloud2
    from hakoniwa_pdu.pdu_msgs.sensor_msgs.pdu_pytype_PointCloud2 import PointCloud2
except ImportError as e:
    print(f"FATAL: Failed to import Hakoniwa libraries: {e}", file=sys.stderr)
    sys.exit(1)

# --- Visualizer Classes ---

class BaseVisualizer:
    def update(self, points):
        pass
    def check_running(self):
        pass
    def close(self):
        pass
    is_running = True

class Open3DVisualizer(BaseVisualizer):
    def __init__(self):
        try:
            import open3d as o3d
            self.o3d = o3d
            self.vis = o3d.visualization.Visualizer()
            self.vis.create_window(window_name="Hakoniwa LiDAR Visualizer 4 (Open3D)")
            
            # Coordinate frame
            coord_frame = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1.0, origin=[0, 0, 0])
            self.vis.add_geometry(coord_frame)
            
            self.pcd = o3d.geometry.PointCloud()
            self.vis.add_geometry(self.pcd)
            self.first = True
            
            print("INFO: Open3D Visualizer started.")
        except ImportError:
            print("ERROR: Open3D not installed. Please install it with `pip install open3d`.", file=sys.stderr)
            self.vis = None
            self.is_running = False
            
    def update(self, points):
        if not self.vis or len(points) == 0:
            return

        self.pcd.points = self.o3d.utility.Vector3dVector(points)
        self.vis.update_geometry(self.pcd)
        self.vis.poll_events()
        self.vis.update_renderer()

    def check_running(self):
        if self.vis:
            if not self.vis.poll_events():
                self.is_running = False
    
    def close(self):
        if self.vis: self.vis.destroy_window()

class MatplotlibVisualizer(BaseVisualizer):
    def __init__(self):
        try:
            import matplotlib.pyplot as plt
            from mpl_toolkits.mplot3d import Axes3D
            self.plt = plt
            self.fig = self.plt.figure(figsize=(10, 8))
            self.ax = self.fig.add_subplot(111, projection='3d')
            self.plt.ion()
            self.plt.show()
            self.scatter = None
            print("INFO: Matplotlib Visualizer started.")
        except ImportError:
            print("ERROR: Matplotlib not installed.", file=sys.stderr)
            self.is_running = False

    def update(self, points):
        if len(points) == 0: return
        
        # Downsample for performance if needed
        if len(points) > 1000:
            indices = np.random.choice(len(points), 1000, replace=False)
            points = points[indices]

        self.ax.cla()
        x, y, z = points[:, 0], points[:, 1], points[:, 2]
        
        self.ax.scatter(x, y, z, s=1, c=z, cmap='jet')
        
        self.ax.set_xlabel('X')
        self.ax.set_ylabel('Y')
        self.ax.set_zlabel('Z')
        self.ax.set_xlim(-10, 10)
        self.ax.set_ylim(-10, 10)
        self.ax.set_zlim(-5, 5)
        
        self.plt.pause(0.001)

    def check_running(self):
        if not self.plt.fignum_exists(self.fig.number):
            self.is_running = False

    def close(self):
        self.plt.close(self.fig)

class PyQt5Visualizer(BaseVisualizer):
    def __init__(self):
        try:
            from PyQt5.QtWidgets import QApplication
            import pyqtgraph.opengl as gl
            import pyqtgraph as pg
            self.gl = gl
            self.pg = pg
            self.QApplication = QApplication
        except ImportError:
            print("ERROR: PyQt5 or pyqtgraph not installed. Install via `pip install PyQt5 pyqtgraph`.", file=sys.stderr)
            self.is_running = False
            return

        # Create QApplication if it doesn't exist
        self.app = self.QApplication.instance()
        if self.app is None:
            self.app = self.QApplication(sys.argv)

        self.widget = self.gl.GLViewWidget()
        self.widget.opts['distance'] = 20
        self.widget.setWindowTitle('Hakoniwa LiDAR Visualizer 4 (PyQt5)')
        self.widget.setGeometry(100, 100, 800, 600)
        self.widget.show()

        # Add Grid
        g = self.gl.GLGridItem()
        g.scale(2, 2, 1)
        self.widget.addItem(g)

        # Add Coordinate Axes
        axis = self.gl.GLAxisItem()
        self.widget.addItem(axis)

        # Scatter Plot Item
        self.scatter = self.gl.GLScatterPlotItem(pos=np.zeros((1,3)), size=3, color=(0, 1, 0, 1), pxMode=True)
        self.widget.addItem(self.scatter)

        print("INFO: PyQt5 Visualizer started.")
        self.is_running = True

    def update(self, points):
        if not self.is_running or len(points) == 0:
            return

        # Simple coloring based on Z height or distance
        # points shape is (N, 3) -> x, y, z
        
        # Calculate colors
        # distances = np.linalg.norm(points, axis=1)
        # Normalized colors... for now just green with alpha
        
        # pyqtgraph expects pos as (N, 3)
        self.scatter.setData(pos=points, size=3, color=(0, 1, 0, 0.8), pxMode=True)

    def check_running(self):
        if self.is_running:
            self.app.processEvents()
            if not self.widget.isVisible():
                self.is_running = False

    def close(self):
        if hasattr(self, 'widget') and self.widget.isVisible():
            self.widget.close()

# --- PDU Helper ---

def parse_point_cloud2(pdu: PointCloud2) -> np.ndarray:
    if not pdu: return np.empty((0, 3))
    
    # Extract offsets
    x_off, y_off, z_off = -1, -1, -1
    for f in pdu.fields:
        if f.name == 'x': x_off = int(f.offset)
        elif f.name == 'y': y_off = int(f.offset)
        elif f.name == 'z': z_off = int(f.offset)
    
    if x_off < 0 or y_off < 0 or z_off < 0: return np.empty((0, 3))

    data = pdu.data
    width = int(pdu.width)
    height = int(pdu.height)
    point_step = int(pdu.point_step)
    num_points = width * height
    
    points = []
    
    for i in range(num_points):
        base = i * point_step
        try:
            x = struct.unpack_from('<f', data, base + x_off)[0]
            y = struct.unpack_from('<f', data, base + y_off)[0]
            z = struct.unpack_from('<f', data, base + z_off)[0]
            points.append([-y, z, -x]) 
        except struct.error:
            break
            
    return np.array(points)

def get_pdu_info_from_config(config_path, robot_name, pdu_name):
    if not os.path.exists(config_path):
        print(f"WARN: PDU config file not found: {config_path}")
        return None, None
    
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
            
        for robot in config.get('robots', []):
            if robot['name'] == robot_name:
                for writer in robot.get('shm_pdu_writers', []):
                    if writer['org_name'] == pdu_name:
                        return writer['channel_id'], writer['pdu_size']
                for reader in robot.get('shm_pdu_readers', []):
                    if reader['org_name'] == pdu_name:
                        return reader['channel_id'], reader['pdu_size']
        print(f"WARN: Robot '{robot_name}' or PDU '{pdu_name}' not found in {config_path}")
    except Exception as e:
        print(f"ERROR: Failed to parse config: {e}")
        
    return None, None

# --- Main Logic ---

def main():
    parser = argparse.ArgumentParser(description="Hakoniwa LiDAR Visualizer 4 (PyQt5 Supported)")
    parser.add_argument('core_config_path', help='Path to cpp_core_config.json')
    parser.add_argument('--pdu_config_path', default='avatar-drone.json', help='Path to avatar-drone.json (robot definitions)')
    parser.add_argument('--robot_name', default='Drone', help='Name of the robot in config')
    parser.add_argument('--pdu_channel', default='lidar_points', help='PDU channel name')
    parser.add_argument('--mode', default='open3d', choices=['open3d', 'matplotlib', 'pyqt5'], help='Visualization mode')
    parser.add_argument('--delta_msec', type=int, default=100, help='Update interval in msec')
    args = parser.parse_args()

    print("==================================================")
    print(" Hakoniwa LiDAR Visualizer 4")
    print("==================================================")
    print(f" Core Config: {args.core_config_path}")
    print(f" PDU Config:  {args.pdu_config_path}")
    print(f" Robot:       {args.robot_name}")
    print(f" Channel:     {args.pdu_channel}")
    print(f" Mode:        {args.mode}")
    print("==================================================")

    # 0. Get PDU Info
    print(f"INFO: Loading PDU info from {args.pdu_config_path}...")
    channel_id, pdu_size = get_pdu_info_from_config(args.pdu_config_path, args.robot_name, args.pdu_channel)
    if channel_id is None:
        print("ERROR: Could not resolve PDU channel ID. Please check the config file.")
        return 1
    
    print(f"INFO: Target PDU - Channel ID: {channel_id}, Size: {pdu_size}")

    # 1. Initialize for External
    print("INFO: Initializing Hakoniwa for external mode...")
    if not hakopy.init_for_external():
        print("WARNING: init_for_external() returned False. Ensure hakoniwa-core is reachable.")

    # 2. PDU Manager
    print("INFO: Initializing PDU Manager (Core)...")
    pdu_manager = PduManager()
    pdu_manager.initialize(args.core_config_path, ShmCommunicationService())

    # 3. Visualizer
    if args.mode == 'open3d':
        vis = Open3DVisualizer()
    elif args.mode == 'matplotlib':
        vis = MatplotlibVisualizer()
    elif args.mode == 'pyqt5':
        vis = PyQt5Visualizer()
    else:
        print(f"ERROR: Unknown mode {args.mode}")
        return 1

    if not vis.is_running:
        print("ERROR: Failed to initialize visualizer. Exiting.")
        return 1

    print("\nINFO: Starting visualization loop. Press Ctrl+C to exit.")
    
    last_error_time = 0
    error_suppress_interval = 5.0
    
    try:
        while vis.is_running:
            loop_start = time.time()
            
            # PDU Read using Direct API with ID
            try:
                raw_data_bytes = hakopy.pdu_read(args.robot_name, channel_id, pdu_size)
                
                if raw_data_bytes:
                    pdu = pdu_to_py_PointCloud2(raw_data_bytes)
                    points = parse_point_cloud2(pdu)
                    vis.update(points)
                else:
                    pass

            except Exception as e:
                curr_time = time.time()
                if curr_time - last_error_time > error_suppress_interval:
                    print(f"WARN: Failed to read PDU: {e}")
                    last_error_time = curr_time
                
            vis.check_running()
            
            elapsed = time.time() - loop_start
            sleep_sec = (args.delta_msec / 1000.0) - elapsed
            if sleep_sec > 0:
                time.sleep(sleep_sec)

    except KeyboardInterrupt:
        print("\nINFO: Stopped by user.")
    finally:
        print("INFO: Cleaning up...")
        if vis: vis.close()

    return 0

if __name__ == '__main__':
    sys.exit(main())
